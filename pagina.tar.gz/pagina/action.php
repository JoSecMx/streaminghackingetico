<?php
if(isset($_POST['signIn'])){
	echo $_POST['Email'];
}
?>